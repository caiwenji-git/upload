<?php
// Text
$_['text_items']     = '<div class="hdis d-inline-block text-left"><h3 class="hidden-sm hidden-xs hidden-md">My Cart</h3><span id="cart-total"><span class="cartta">%s</span></div>';
$_['text_empty']     = 'Your shopping cart is empty!';
$_['text_cart']      = 'View Cart';
$_['text_checkout']  = 'Checkout';
$_['text_recurring'] = 'Payment Profile';