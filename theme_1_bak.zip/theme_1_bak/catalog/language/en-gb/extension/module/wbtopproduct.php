<?php
// Heading
$_['onsale_title'] = 'Top Product';

// Text
$_['text_tax']      = 'Ex Tax:';