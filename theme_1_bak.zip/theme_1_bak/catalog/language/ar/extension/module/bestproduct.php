<?php
// Heading
$_['bestpro_title'] = 'أعلى التقييمات';

// Text
$_['text_tax']      = 'Ex Tax:';