<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'الاشتراك في القائمة البريدية';
$_['cheading_title']    = 'الاشتراك في القائمة البريدية';

// Text
$_['text_account']     = 'الحساب';
$_['text_newsletter']  = 'القائمة البريدية';
$_['text_success']     = 'تم التعديل !';

// Entry
$_['entry_newsletter'] = 'اشترك:';
