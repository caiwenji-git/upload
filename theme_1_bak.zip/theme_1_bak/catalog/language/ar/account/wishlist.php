<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title'] = 'قائمة رغباتي';
$_['cheading_title'] = 'قائمة رغباتي';

// Text
$_['text_account']  = 'الحساب';
$_['text_instock']  = 'متوفر';
$_['text_wishlist'] = 'قائمة رغباتك (%s)';
$_['text_login']    = '<h2>نجاح !!</h2>يجب عليك أن <a href="%s">تسجيل الدخول</a> or <a href="%s">انشئ حساب</a> للحفظ <a href="%s">%s</a> لك <a href="%s">الأماني</a>!';
$_['text_success']  = '<h2>نجاح !!</h2> لقد قمت بإضافة <a href="%s">%s</a> لك <a href="%s">الأماني</a>!';
$_['text_remove']   = '<h2>نجاح !!</h2> لقد قمت بتعديل قائمة أمنياتك!';
$_['ctext_empty']    = 'قائمة رغباتك فارغة.';

// Column
$_['column_image']  = 'صورة';
$_['column_name']   = 'اسم المنتج';
$_['column_model']  = 'النوع';
$_['column_stock']  = 'حالة التوفر';
$_['column_price']  = 'سعر الوحدة';
$_['column_action'] = 'تحرير';