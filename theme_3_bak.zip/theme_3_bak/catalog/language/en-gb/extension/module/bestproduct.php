<?php
// Heading
$_['bestpro_title'] = 'Top rated';

// Text
$_['text_tax']      = 'Ex Tax:';