<?php
// Heading
$_['heading_title'] = 'Featured';
$_['tab_titlem'] = 'popular products';
$_['best_title'] = 'bestseller';
$_['sep_title'] = 'latest';
// Text
$_['text_tax']      = 'Ex Tax:';