<?php
// Heading 
$_['heading_title']    = 'Latest Blog';

// Text
$_['date_format_short']     = 'd M, Y';
$_['date_format_long']     = 'd M, Y';
$_['text_read_more']   = 'read more';
$_['text_date_added']  = 'Date Added:';
$_['entry_comment']       = 'Comments';
$_['text_comment']   = 'Leave Comments';

// Button
$_['button_all_blogs'] = 'See all Blogs';