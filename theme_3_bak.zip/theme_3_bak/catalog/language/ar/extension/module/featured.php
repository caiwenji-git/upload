<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title'] = 'متميز';
$_['tab_title'] = 'تتجه المنتج';
$_['latest_title'] = 'آخر';
$_['best_title'] = 'الأكثر مبيعًا';
$_['sep_title'] = 'آخر';

// Text
$_['text_tax']      = 'السعر بدون الضريبة:';