<?php
// Text
$_['text_search'] 		 = 'بحث';
$_['text_category']      = 'جميع الفئات';
$_['text_empty']        = 'لا يوجد منتج يطابق معايير البحث.';
$_['text_tax']        = 'السابق الضرائب:';
