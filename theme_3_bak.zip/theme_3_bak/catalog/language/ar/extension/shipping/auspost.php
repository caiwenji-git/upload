<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_title']    = 'البريد الالسترالي - Australia Post';
$_['text_express']  = 'شحن سريع';
$_['text_standard'] = 'شحن عادي';
$_['text_eta']      = 'أيام';