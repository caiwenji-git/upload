<?php
// header
$_['phone_number']                = '(+1)866-540-3229';
$_['text_phone']                  = 'Free shipping for standard order over $100';
$_['entry_settings']                = 'Settings';
// Categories box
$_['categories_box_title']        = 'Categories';


