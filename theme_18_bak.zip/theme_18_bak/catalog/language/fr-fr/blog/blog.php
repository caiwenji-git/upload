<?php
// Text
$_['button_read_more']         		 = 'Read more';
$_['text_empty']           			 = 'No articles';
$_['text_headingtitle']           			 = 'Latest From Our blog';
$_['text_blog'] = 'Blog';
$_['text_post_by'] = 'posted by: ';
