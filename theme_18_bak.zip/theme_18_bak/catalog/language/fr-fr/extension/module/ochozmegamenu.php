<?php
// Heading 
$_['heading_title'] = 'Hozmegamenu';
$_['text_menu'] = 'Menu';
$_['text_categories'] = 'Categories';

// Text
$_['text_reviews']  = 'Based on %s reviews.';