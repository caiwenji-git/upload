<?php
// Locale
$_['categories_box_title']  = 'Categories';
//Home 4
$_['shipping_text']           = 'Freeshipping for all order over $100. ';