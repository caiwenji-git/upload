<?php
// Text
$_['button_read_more']         		 = 'Read more';
$_['text_empty']           			 = 'No articles';
$_['text_headingtitle']           			 = 'Latest From Our blog';
$_['text_blog'] = 'Blog';
$_['text_post_by'] = 'posted by: ';
$_['title_des'] = 'Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio';

