<?php
// Heading
$_['heading_title'] = 'New Arrivals';

// Text
$_['text_tax']      = 'Ex Tax:';
$_['text_reviews']             = '%s reviews';
$_['text_sale']      = 'Sale';
$_['text_new']      = 'New';
$_['text_empty']    = 'There is no New Products!';
$_['shop_now_text']      = 'Shop now';