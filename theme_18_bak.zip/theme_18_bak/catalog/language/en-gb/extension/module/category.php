<?php
// Heading
$_['heading_title'] = 'Categories';
$_['categories_box_title'] = 'Categories';
