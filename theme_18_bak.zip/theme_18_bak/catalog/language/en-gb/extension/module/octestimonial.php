<?php
// Heading 
$_['heading_title']  = 'Latest Testimonials';
$_['text_readmore']  = 'Read more';
$_['text_empty']  = 'There is no testimonial';
$_['title_des']  = 'Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.';
?>