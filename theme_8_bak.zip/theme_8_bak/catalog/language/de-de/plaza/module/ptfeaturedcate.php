<?php
$_['title'] = "Shop By Categories";
$_['text_special_categories'] = "";
$_['text_products'] = "products";
$_['text_shop_now'] = "Shop now";