<?php
$_['text_vertical_bar'] = 'Vertical Menu';
$_['text_mobile_bar'] = 'Mobile Menu';
$_['text_more_item'] = 'More Items';
$_['text_close_item'] = 'Close Items';