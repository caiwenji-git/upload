<?php
// Text
$_['button_read_more']         		 = 'Read more';
$_['text_blog_empty']           			 = 'No articles';
$_['text_post_by']           			 = 'by ';
$_['text_blog'] = 'Blog';
$_['text_headingtitle']           			 = 'Latest Blog Posts';
$_['module_description']           			 = 'There are latest blog posts';
