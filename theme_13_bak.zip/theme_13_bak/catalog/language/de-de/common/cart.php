<?php
// Text
$_['text_items']     = '<span class="txt_number">%s</span><span class="txt_items">My Cart </span><span class="total-price">%s</span>';

$_['text_empty']     = 'Your shopping cart is empty!';
$_['text_cart']      = 'View Cart';
$_['text_checkout']  = 'Checkout';
$_['text_recurring'] = 'Payment Profile';