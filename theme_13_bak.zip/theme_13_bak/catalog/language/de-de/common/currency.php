<?php
// Text
$_['text_currency'] = 'Currency';
$_['text_currency2'] = 'Curr';