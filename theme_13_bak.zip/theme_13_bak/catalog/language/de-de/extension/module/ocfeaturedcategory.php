<?php
// Heading
$_['heading_title'] = 'Featured Categories';

$_['text_items'] = 'products';
$_['view_more'] = 'shop now';