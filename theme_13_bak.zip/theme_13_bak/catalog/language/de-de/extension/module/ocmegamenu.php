<?php
$_['text_vertical_bar'] = 'Browse categories';
$_['text_mobile_bar'] = 'Mobile Menu';
$_['text_more'] = 'More Categories';
$_['text_close'] = 'Hide Categories';