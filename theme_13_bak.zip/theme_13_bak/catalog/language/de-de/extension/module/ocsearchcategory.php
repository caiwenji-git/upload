<?php
// Text
$_['text_category']     = 'All Categories';
$_['text_empty']        = 'There is no product that matches the search criteria.';
$_['text_tax']        = 'Ex Tax:';
$_['text_search'] = 'Search entire store here ...';
$_['button_search'] = 'Search';
