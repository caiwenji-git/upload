<?php
// Heading
$_['heading_title']    = 'Our Twitter Feed';
