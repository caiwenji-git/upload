<?php
// Heading
$_['heading_title']    = 'Follow us On Instagram';
$_['module_description']    = 'Displays an Instagram feed of your photos from your Instagram account on your website. ';

$_['link_follow']        = '<a href="https://www.instagram.com/plazaalula/" target="_blank">Follow on instagram</a>';
$_['link_follow2']        = '<a href="https://www.instagram.com/plazaalula2/" target="_blank">Follow on instagram</a>';
$_['link_follow4']        = '<a href="https://www.instagram.com/plazaalula4/" target="_blank">Follow on instagram</a>';
$_['text_des']        = 'View Our 2016 Lookbook Feed';
$_['text_copyright']        = 'Instagram -- &copy; %s';
$_['text_error']        = 'Server not found';