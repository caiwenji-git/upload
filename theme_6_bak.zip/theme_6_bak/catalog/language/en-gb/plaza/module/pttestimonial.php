<?php
$_['title']  = 'Testimonials';
$_['text_module_testimonial']  = 'What they say';
$_['text_empty']     = 'There is no testimonial';