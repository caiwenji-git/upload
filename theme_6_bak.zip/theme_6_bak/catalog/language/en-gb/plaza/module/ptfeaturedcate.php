<?php
$_['title'] = "Featured Categories";
$_['text_module_special'] = "Shop By Categories";
$_['text_products'] = "products";
$_['text_shop_now'] = "Shop Now";