<?php
// Text
$_['text_heading_title']  = 'Latest Blogs';
$_['text_module_blog']  = '';
$_['text_post_empty']     = 'No posts';
$_['text_blog']           = 'Blog';
$_['text_limit']          = 'Limit';
$_['text_category_title'] = 'Categories';
$_['text_latest_post']    = 'Latest Post';
$_['text_related_post']   = 'Related Post';
$_['sub_title_blog']   = 'Read Our Blog';

// Button
$_['button_show']         = 'Shop Now';
