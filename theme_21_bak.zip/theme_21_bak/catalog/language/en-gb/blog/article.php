<?php
// Text
$_['text_search']                             = 'Search';
$_['text_post_by'] = 'Posted by';