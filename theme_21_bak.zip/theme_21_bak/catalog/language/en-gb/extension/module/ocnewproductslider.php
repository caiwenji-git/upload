<?php
// Heading
$_['heading_title'] = 'New Arrivals';

// Text
$_['text_tax']      = 'Ex Tax:';
$_['text_reviews']             = '%s reviews';
$_['text_sale']      = 'Sale';
$_['text_new']      = 'New';
$_['text_empty']    = 'There is no New Products!';
$_['text_subtitle']    = 'Shop Laptop feature only the best laptop deals on the market.';