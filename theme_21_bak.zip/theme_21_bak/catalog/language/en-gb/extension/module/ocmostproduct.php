<?php
// Heading
$_['heading_title'] = 'Most Viewed Products';

// Text
$_['text_tax']      = 'Ex Tax:';
$_['text_sale']      = 'Sale';
$_['text_new']      = 'New';
$_['text_empty']    = 'There is no Most Viewed Products!';
$_['text_subtitle']    = 'When it comes to TVs, there are choices galore on Flipkart.';