<?php
// Heading
$_['heading_title'] = 'Tab Category slider';

// Text
$_['text_tax']      = 'Ex Tax:';
$_['text_sale']      = 'Sale';
$_['text_new']      = 'New';
$_['text_empty']    = 'There is no products match this category';
$_['text_subtitle']    = 'When it comes to TVs, there are choices galore on Flipkart.';
$_['text_count_products']    = '<span class="count_products">%s<span>';
