<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title'] = 'الأكثر مبيعاً';

// Text
$_['text_tax']      = 'السعر بدون الضريبة:';