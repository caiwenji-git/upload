<?php
// Heading
$_['onsale_title'] = 'صفقة اليوم';

// Text
$_['text_tax']      = 'السابق الضرائب:';