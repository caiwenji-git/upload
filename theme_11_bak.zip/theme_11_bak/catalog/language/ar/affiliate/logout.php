<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading 
$_['heading_title'] = 'خروج';

// Text
$_['text_message']  = '<p>لقد قمت بتسجيل الخروج بنجاح من نظام العمولة.</p>';
$_['text_account']  = 'الحساب';
$_['text_logout']   = 'خروج';