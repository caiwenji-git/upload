<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_information']  = 'معلومات';
$_['text_service']      = 'خدمات العملاء';
$_['text_extra']        = 'إضافات';
$_['text_contact']      = 'اتصل بنا';
$_['text_return']       = 'إرجاع الطلب';
$_['text_sitemap']      = 'خريطة الموقع';
$_['text_manufacturer'] = 'الشركات';
$_['text_voucher']      = 'قسائم الهدايا';
$_['text_affiliate']    = 'نظام العمولة';
$_['text_special']      = 'العروض المميزة';
$_['text_account']      = 'حسابي';
$_['text_order']        = 'طلباتي';
$_['text_wishlist']     = 'قائمة رغباتي';
$_['text_newsletter']   = 'القائمة البريدية';
$_['text_powered']      = 'ترجمة <a href="http://www.opencart.com" target="_blank">OpenCart</a> %s &copy; %s';