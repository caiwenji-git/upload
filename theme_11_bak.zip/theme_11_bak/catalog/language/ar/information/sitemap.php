<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'خريطة الموقع';
$_['cheading_title']    = 'خريطة الموقع';

// Text
$_['text_special']     = 'العروض المميزة';
$_['text_account']     = 'حسابي';
$_['text_edit']        = 'معلومات الحساب';
$_['text_password']    = 'كلمة المرور';
$_['text_address']     = 'دفتر العناوين';
$_['text_history']     = 'طلباتي';
$_['text_download']    = 'التنزيلات';
$_['text_cart']        = 'سلة الشراء';
$_['text_checkout']    = 'انهاء الطلب';
$_['text_search']      = 'بحث';
$_['text_information'] = 'معلومات';
$_['text_contact']     = 'اتصل بنا';