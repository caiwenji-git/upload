<?php
// Text
$_['text_home']          = 'Home';
// Edit by Plazathemes
$_['text_wishlist']      = '<span class="text-wishlist">Wish List</span> <span class="txt-count">%s</span>';
$_['text_call_us']      = 'Call Us:';
$_['text_store_locator']      = 'Store Locator';
$_['text_header']      = 'Free Shipment From 100 Eur (EU) <a href="#">Learn More</a>';

// End edit
$_['text_shopping_cart'] = 'Shopping Cart';
$_['text_category']      = 'Categories';
$_['text_account']       = 'My Account';
$_['text_register']      = 'Register';
$_['text_login']         = 'Or Sign In';
$_['text_order']         = 'Order History';
$_['text_transaction']   = 'Transactions';
$_['text_download']      = 'Downloads';
$_['text_logout']        = 'Logout';
$_['text_checkout']      = 'Checkout';
$_['text_search']        = 'Search';
$_['text_all']           = 'Show All';
$_['text_phone']           = '+1 123 888 9999';
$_['text_social']           = 'Follow us';
$_['text_welcome']           = 'Additional <span class="text">20% Off</span> Sale Items – Please See Details';