<?php
// Heading
$_['onsale_title'] = 'On Sale';

// Text
$_['text_tax']      = 'Ex Tax:';