<?php
// Heading
$_['heading_title'] = 'Arrivel';
$_['hArrivel'] = 'Arrivel';
// Text
$_['text_tax']      = 'Ex Tax:';