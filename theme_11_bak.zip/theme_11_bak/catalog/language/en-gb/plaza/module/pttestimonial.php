<?php
$_['title']  = 'What Our Customers Say';
$_['text_module_testimonial']  = 'What they say';
$_['text_empty']     = 'There is no testimonial';