<?php
$_['title'] = "Popular Categories";
$_['text_special_categories'] = "";
$_['text_products'] = "products";
$_['text_view_all'] = "View All";