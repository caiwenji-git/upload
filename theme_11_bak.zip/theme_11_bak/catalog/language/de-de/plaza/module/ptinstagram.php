<?php
// Heading

// Text

$_['text_des']         = 'Lookbook Feed';
$_['text_copyright']   = 'Instagram -- &copy; %s';
$_['text_error']       = 'Server not found';