<?php
$_['title'] = "Popular Categories";
$_['text_module_special'] = "Add popular categories to weekly line up";
$_['text_products'] = "products";
$_['text_shop_now'] = "Shop Now";