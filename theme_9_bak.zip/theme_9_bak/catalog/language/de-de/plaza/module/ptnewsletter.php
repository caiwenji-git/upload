<?php
// Newsletter Popup
$_['heading_title1'] 	    = 'Sign Up Newsletter';
$_['text_description'] 	    = "Enjoy our newsletter to stay updated with the latest news and special sales. Let's your email address here!";

// Newsletter Block
$_['heading_title2'] 	    = 'Subscribe for Newsletter';
$_['text_description2'] 	    = "Get Discount Coupon";
$_['text_description3'] 	    = "Get E-mail updates about our latest shop and special offers.";

// Text
$_['text_close']            = 'Close';
$_['text_notification']     = 'Don\'t show again';

// Entry
$_['entry_mail_subscribe']  = 'Please enter your email to subscribe';

// Buttons
$_['button_subscribe']      = 'Subscribe';

// Messages
$_['subscribe_success']     = 'Success: Your e-mail has been subscribed successfully!';
$_['error_validate_mail']   = "Invalid E-mail Address!";
$_['error_existed_mail']    = "This E-mail is existed already!";