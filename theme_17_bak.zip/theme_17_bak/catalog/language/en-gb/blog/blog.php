<?php
// Text
$_['button_read_more']         		 = 'Read more';
$_['text_empty']           			 = 'No articles';
$_['text_headingtitle']           			 = 'Latest From Our blog';
$_['text_blog'] = 'Blog';
$_['text_post_by'] = 'Poted by: ';
$_['text_all_blog'] = 'view all blogs';
$_['text_module_des'] = 'We deliver breaking news from across the globe: information on the latest technology and unbiased expert product reviews of HDTVs, laptops, smartphones and more.';
$_['text_module_des2'] = '<i class="icon-bubble"></i> We provide the best Quality of products to you.';
