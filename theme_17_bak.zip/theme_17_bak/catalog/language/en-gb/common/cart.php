<?php
// Text
$_['text_items']     = '<span class="text-top-cart">shopping cart</span><span class="item-top-cart"><em>%s</em><span>Price: %s</span></span>';
$_['text_empty']     = 'Your shopping cart is empty!';
$_['text_cart']      = 'View Cart';
$_['text_checkout']  = 'Checkout';
$_['text_recurring'] = 'Payment Profile';