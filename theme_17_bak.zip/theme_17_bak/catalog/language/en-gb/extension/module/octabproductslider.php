<?php
// Heading
$_['heading_title'] = 'Product Tabs Slider';

// Text
$_['text_tax']      = 'Ex Tax:';
$_['text_bestseller']   = 'Bestseller';
$_['text_mostviewed']      = 'Most Viewed';
$_['text_random']      = 'Random';
$_['text_special']      = 'Special';
$_['text_latest']      = 'Latest';
$_['text_sale']      = 'Sale';
$_['text_new']      = 'New';
$_['text_empty_mostviewed']    = 'There is no Most Viewed Products!';
$_['text_empty_random']    = 'There is no Random Products!';
$_['text_empty_special']    = 'There is no Special Products!';
$_['text_empty_latest']    = 'There is no New Products!';
$_['text_empty_bestseller']    = 'There is no Bestseller Products!';