<?php
// Heading
$_['title'] = 'Our Brands';