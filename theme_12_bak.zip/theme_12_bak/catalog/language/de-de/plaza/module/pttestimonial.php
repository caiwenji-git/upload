<?php
$_['title']  = 'Testimonials';
$_['text_module_testimonial']  = 'What our happy customers says !';
$_['text_empty']     = 'There is no testimonial';