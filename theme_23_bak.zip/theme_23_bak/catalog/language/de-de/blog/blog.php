<?php
// Text
$_['button_read_more']         		 = 'Read more';
$_['text_empty']           			 = 'No articles';
$_['text_post_by']           			 = 'post by: ';
$_['text_headingtitle']           			 = 'LATEST BLOG POST';
$_['text_blog'] = 'Blog';
$_['text_subtitle'] = 'Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum.';
