<?php
$_['text_readmore'] = 'view collection';