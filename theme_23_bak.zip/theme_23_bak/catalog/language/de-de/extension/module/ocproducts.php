<?php
$_['heading_title']    = 'Products module';

// Text
$_['text_empty']    = 'There is no product';
$_['text_years']    = 'Years';
$_['text_months']    = 'Months';
$_['text_weeks']    = 'Weeks';
$_['text_days']    = 'Days';
$_['text_hrs']    = 'Hrs';
$_['text_mins']    = 'Mins';
$_['text_secs']    = 'Secs';

$_['text_year']    = 'Year';
$_['text_month']    = 'Month';
$_['text_week']    = 'Week';
$_['text_day']    = 'Day';
$_['text_hr']    = 'Hr';
$_['text_min']    = 'Min';
$_['text_sec']    = 'Sec';

$_['price_label']    = 'Price:';
$_['text_stock']    = 'Available:';
$_['text_instock']    = 'In Stock';
