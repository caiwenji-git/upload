<?php
// Text
$_['text_language'] = 'Language';
$_['text_language2'] = 'Lang';