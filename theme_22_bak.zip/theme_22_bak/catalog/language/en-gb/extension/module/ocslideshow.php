<?php
$_['text_readmore'] = 'Shop Now!';