<?php
// Heading 
$_['heading_title'] = 'Menu';
$_['category_title'] = 'Categories';
$_['menu_title'] = 'Menu';

// Text
$_['text_reviews']  = 'Based on %s reviews.';