<?php
// Heading
$_['text_headingtitle']    = 'Logo Brands';