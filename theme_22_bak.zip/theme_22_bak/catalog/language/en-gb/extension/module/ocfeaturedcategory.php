<?php
// Heading
$_['heading_title'] = 'Shop by Category';