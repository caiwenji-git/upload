<?php
// Heading 
$_['heading_title'] = 'All Derpartment';

// Text
$_['text_more_vertical_menu'] = '<i class="ion-more"></i>More Categories';
$_['text_close_vertical_menu'] = '<i class="ion-more"></i>Close Menu';