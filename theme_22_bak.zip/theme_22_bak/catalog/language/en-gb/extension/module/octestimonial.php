<?php
// Heading 
$_['heading_title']  = 'What Clients Say?';
$_['text_readmore']  = 'Read more';
$_['text_empty']  = 'There is no testimonial';
?>