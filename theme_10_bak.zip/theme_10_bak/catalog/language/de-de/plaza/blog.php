<?php
// Text
$_['text_heading_title']  = 'Recent Blog Posts';
$_['text_post_empty']     = 'No posts';
$_['text_blog']           = 'Blog';
$_['text_limit']          = 'Limit';
$_['text_category_title'] = 'Categories';
$_['text_latest_post']    = 'Latest Post';
$_['text_related_post']   = 'Related Post';

// Button
$_['button_show']         = 'Read More';
