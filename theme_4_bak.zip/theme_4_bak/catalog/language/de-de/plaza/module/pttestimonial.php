<?php
$_['title']  = 'What our Clients say';
$_['text_module_testimonial']  = 'Welcome to my personal presentation';
$_['text_empty']     = 'There is no testimonial';