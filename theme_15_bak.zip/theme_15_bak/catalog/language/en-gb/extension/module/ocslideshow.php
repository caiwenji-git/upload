<?php
$_['text_readmore'] = 'shop now';
$_['text_readmore_home6'] = 'check new arrivals';