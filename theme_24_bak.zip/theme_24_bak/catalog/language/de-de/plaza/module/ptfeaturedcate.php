<?php
$_['title'] = "Featured Categories";
$_['sub_title'] = "Top Featured Collections";
$_['text_products'] = "products";
$_['text_view_more'] = "view more";