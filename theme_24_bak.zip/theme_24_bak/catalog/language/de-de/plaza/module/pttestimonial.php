<?php
$_['title']  = 'What’s Client Says';
$_['text_empty']     = 'There is no testimonial';