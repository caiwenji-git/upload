<?php
// Heading
$_['heading_title']    = 'Follow us On Instagram';
// Text
$_['text_module_instagram']      = 'Displays an Instagram feed of your photos from your Instagram account on your website.';
$_['text_follow']      = 'Follow us on Instagram';
$_['text_des']         = 'Lookbook Feed';
$_['text_copyright']   = 'Instagram -- &copy; %s';
$_['text_error']       = 'Server not found';