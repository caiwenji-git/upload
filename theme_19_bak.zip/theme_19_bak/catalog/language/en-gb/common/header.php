<?php
// Text
$_['text_home']          = 'Home';
$_['text_wishlist']      = '%s';
$_['text_shopping_cart'] = 'Shopping Cart';
$_['text_category']      = 'Categories';
$_['text_namephone']      = 'Call us now: ';
$_['text_account']       = 'My Account';
$_['text_register']      = 'Register';
$_['text_login']         = 'Login';
$_['text_order']         = 'Order History';
$_['text_transaction']   = 'Transactions';
$_['text_download']      = 'Downloads';
$_['text_logout']        = 'Logout';
$_['text_checkout']      = 'Checkout';
$_['text_search']        = 'Search';
$_['text_all']           = 'Show All';
$_['text_phone']           = 'Call us now: <span>+0123 456 78 89</span>';
$_['text_message2']           = 'Wellcome %s to store!';
$_['text_message']           = 'Week Days: 08:00am–7:30pm';
