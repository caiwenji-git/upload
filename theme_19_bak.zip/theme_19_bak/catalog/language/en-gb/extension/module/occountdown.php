<?php
$_['heading_title']     = 'Special Offers';

//Text
$_['text_reviews']      = '%s reviews';
$_['text_years']        = "Years";
$_['text_months']       = "Months";
$_['text_weeks']        = "Weeks";
$_['text_days']         = "Days";
$_['text_hours']        = "Hours";
$_['text_minutes']      = "Mins";
$_['text_seconds']      = "Secs";
$_['text_sale']      = 'Sale';
$_['text_new']      = 'New';
$_['text_empty']    = 'There is no Products has Price Countdown!';
$_['text_hurryup']    = 'Hurry Up! Offer ends in:';
?>
