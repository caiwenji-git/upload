<?php
// Heading
$_['heading_title']    = 'our brands';