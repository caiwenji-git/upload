<?php
// Heading
$_['heading_title'] = 'shop by';
$_['text_byprice'] = 'By price';
$_['text_sale']      = 'Sale';
$_['text_new']      = 'New';