<?php
// Heading 
$_['heading_title']  = 'Latest Testimonials';
$_['heading_title2']  = 'Testimonials';
$_['text_readmore']  = 'Read more';
$_['text_empty']  = 'There is no testimonial';
?>