<?php
// Heading
$_['heading_title'] = 'Most Viewed Products';
$_['heading_title2'] = 'Trending & stunning. Unique.';

// Text
$_['text_tax']      = 'Ex Tax:';
$_['text_sale']      = 'Sale';
$_['text_new']      = 'New';
$_['text_empty']    = 'There is no Most Viewed Products!';