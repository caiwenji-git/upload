<?php
// Heading
$_['cheading_title'] = 'Our category';