<?php 
	$_['heading_title'] = 'QuickView';
	$_['filter_group_categories_name'] = 'Categories';
	$_['filter_group_price_name']  = 'Price range';
	$_['filter_group_selection']   = 'Refine by:';
?>