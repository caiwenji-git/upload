<?php
// Text
$_['text_items']     = '<div class="hdis d-inline-block text-left"><h3 class="hidden-sm hidden-xs">My Cart</h3><span id="cart-total"><span class="cartta">%s</span><span class="hidden-xs hidden-sm"> Item</span></span></div>';
$_['text_empty']     = 'Your shopping cart is empty!';
$_['text_cart']      = 'View Cart';
$_['text_checkout']  = 'Checkout';
$_['text_recurring'] = 'Payment Profile';