<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['category_title'] = 'أقسام الموقع';
$_['text_category'] = 'كل فئة';