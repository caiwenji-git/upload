<?php
// Heading
$_['heading_title'] = 'أعلى الفئة';