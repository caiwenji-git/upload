<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_items']    = '<div class="hdis d-inline-block text-left"><h3 class="hidden-sm hidden-xs">سلة التسوق</h3><span id="cart-total"><span class="cartta">%s</span><span class="hidden-xs hidden-sm"> بند</span></span></div>';
$_['text_empty']    = 'سلة الشراء فارغة !';
$_['text_cart']     = 'معاينة السلة';
$_['text_checkout'] = 'إنهاء الطلب';
$_['text_recurring']  = 'ملف الدفع';
$_['text_shopcart'] = 'عربة التسوق';